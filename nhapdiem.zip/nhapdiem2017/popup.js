var jsInitCmd = 'var nuilastid = \'none\';\n'+
'var nuicurrentrow = 0;\n'+
'var nuid = document.getElementsByTagName(\'input\');\n'+
'for (var i=0 ; i<nuid.length ; i++) { var dataid = nuid[i].getAttribute(\'data-id\');\n'+
'	if (dataid != null) {\n'+
'		var dataparts = dataid.split(\'_\');\n'+
'		if (dataparts != null && !isNaN(dataparts[0])) {\n'+
'			if (nuilastid != dataparts[0]) nuicurrentrow++;\n'+
'			nuilastid = dataparts[0];\n'+
'			dataparts[0] = \'\';\n'+
'			nuid[i].setAttribute(\'id\', \'n\'+nuicurrentrow+dataparts.join(\'_\'));\n'+
'		}\n'+
'	}\n'+
'}';

function generateJSInject(strdata) {
	var data = strdata.replace(/\'/g, "").split('=');
	if (data == null || data.length < 2
		|| !((/^[0-9]$/.test(data[1]))
		  || (/^[0-9][0-9]$/.test(data[1]))
		  || (/^[0-9].[0-9]$/.test(data[1]))
		  || (/^[0-9].[0-9][0-9]$/.test(data[1])))
		|| +(data[0].substring(1,3)) < 12) return '';
	
	var col = data[0].substring(0,1).charCodeAt(0);
	var row = +(data[0].substring(1,3))-11;
	
	if (getIdByCol(col) != null) {
		var js = '';
		js += '$(\'#n\'+'+row+'+\''+getIdByCol(col)+'\').val(\''+data[1]+'\');';
		js += '$(\'#n\'+'+row+'+\''+getIdByCol(col)+'\').change();\n';
		return js;
	}
	
	return '';

	function getIdByCol(col) {
		if (col == 68) return '_1_1_1';
		else if (col == 69) return '_1_1_2';
		else if (col == 70) return '_1_1_3';
		else if (col == 71) return '_1_2_1';
		else if (col == 72) return '_1_2_2';
		else if (col == 73) return '_1_2_3';
		else if (col == 74) return '_1_2_4';
		else if (col == 75) return '_1_2_5';
		else if (col == 76) return '_1_3_1';
		else if (col == 77) return '_1_3_2';
		else if (col == 78) return '_2_2_1';
		else if (col == 79) return '_2_2_2';
		else if (col == 80) return '_2_2_3';
		else if (col == 81) return '_2_2_4';
		else if (col == 82) return '_2_2_5';
		else if (col == 83) return '_2_3_1';
		else if (col == 84) return '_2_3_2';
		else if (col == 85) return '_3_4_1';
		else return null; // accept from D to U only
	}
}

/*jshint browser:true */
/*global XLSX */
var X = XLSX;
var XW = {
	/* worker message */
	msg: 'xlsx',
	/* worker scripts */
	rABS: './xlsxworker2.js',
	norABS: './xlsxworker1.js',
	noxfer: './xlsxworker.js'
};

var rABS = typeof FileReader !== "undefined" && typeof FileReader.prototype !== "undefined" && typeof FileReader.prototype.readAsBinaryString !== "undefined";
var use_worker = typeof Worker !== 'undefined';
var transferable = use_worker;

var wtf_mode = false;

function fixdata(data) {
	var o = "", l = 0, w = 10240;
	for(; l<data.byteLength/w; ++l) o+=String.fromCharCode.apply(null,new Uint8Array(data.slice(l*w,l*w+w)));
	o+=String.fromCharCode.apply(null, new Uint8Array(data.slice(l*w)));
	return o;
}

function ab2str(data) {
	var o = "", l = 0, w = 10240;
	for(; l<data.byteLength/w; ++l) o+=String.fromCharCode.apply(null,new Uint16Array(data.slice(l*w,l*w+w)));
	o+=String.fromCharCode.apply(null, new Uint16Array(data.slice(l*w)));
	return o;
}

function s2ab(s) {
	var b = new ArrayBuffer(s.length*2), v = new Uint16Array(b);
	for (var i=0; i != s.length; ++i) v[i] = s.charCodeAt(i);
	return [v, b];
}

function xw_noxfer(data, cb) {
	var worker = new Worker(XW.noxfer);
	worker.onmessage = function(e) {
		switch(e.data.t) {
			case 'ready': break;
			case 'e': console.error(e.data.d); break;
			case XW.msg: cb(JSON.parse(e.data.d)); break;
		}
	};
	var arr = rABS ? data : btoa(fixdata(data));
	worker.postMessage({d:arr,b:rABS});
}

function xw_xfer(data, cb) {
	var worker = new Worker(rABS ? XW.rABS : XW.norABS);
	worker.onmessage = function(e) {
		switch(e.data.t) {
			case 'ready': break;
			case 'e': console.error(e.data.d); break;
			default: xx=ab2str(e.data).replace(/\n/g,"\\n").replace(/\r/g,"\\r"); console.log("done"); cb(JSON.parse(xx)); break;
		}
	};
	if(rABS) {
		var val = s2ab(data);
		worker.postMessage(val[1], [val[1]]);
	} else {
		worker.postMessage(data, [data]);
	}
}

function xw(data, cb) {
	transferable = true;
	if(transferable) xw_xfer(data, cb);
	else xw_noxfer(data, cb);
}

function get_radio_value( radioName ) {
	var radios = document.getElementsByName( radioName );
	for( var i = 0; i < radios.length; i++ ) {
		if( radios[i].checked || radios.length === 1 ) {
			return radios[i].value;
		}
	}
}

function to_json(workbook) {
	var result = {};
	workbook.SheetNames.forEach(function(sheetName) {
		var roa = X.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
		if(roa.length > 0){
			result[sheetName] = roa;
		}
	});
	return result;
}

function to_csv(workbook) {
	var result = [];
	workbook.SheetNames.forEach(function(sheetName) {
		var csv = X.utils.sheet_to_csv(workbook.Sheets[sheetName]);
		if(csv.length > 0){
			result.push("SHEET: " + sheetName);
			result.push("");
			result.push(csv);
		}
	});
	return result.join("\n");
}

function to_formulae(workbook) {
	console.log("start now");
	//var result = [];
	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	//workbook.SheetNames.forEach(function(sheetName) {
	var jsToInject = '';
	jsToInject += jsInitCmd;
	var sheetName = workbook.SheetNames[0];
		var formulae = X.utils.get_formulae(workbook.Sheets[sheetName]);
		if(formulae.length > 0){
			//result.push("SHEET: " + sheetName);
			//result.push("");
			//result.push(formulae.join("\n"));
			formulae.forEach(function(e) {
				jsToInject += generateJSInject(e);
			});

			chrome.tabs.executeScript(null, {file:'jquery.min.js'}, function() {
				chrome.tabs.executeScript(null, {code: jsToInject});
			});
		}
	//});
	//return result.join("\n");
	return 'Đã xong!\nHãy kiểm tra lại 1 lần nữa trước khi bấm \"Cập nhật\".';
	//return jsToInject;
}

function to_html(workbook) {
	document.getElementById('htmlout').innerHTML = "";
	var result = [];
	workbook.SheetNames.forEach(function(sheetName) {
		var htmlstr = X.write(workbook, {sheet:sheetName, type:'binary', bookType:'html'});
		document.getElementById('htmlout').innerHTML += htmlstr;
	});
}

var tarea = document.getElementById('b64data');
function b64it() {
	if(typeof console !== 'undefined') console.log("onload", new Date());
	var wb = X.read(tarea.value, {type: 'base64',WTF:wtf_mode});
	process_wb(wb);
}

var global_wb;
function process_wb(wb) {
	global_wb = wb;
	var output = "";
	/*switch(get_radio_value("format")) {
		case "json":
			output = JSON.stringify(to_json(wb), 2, 2);
			break;
		case "form":
			output = to_formulae(wb);
			break;
		case "html": return to_html(wb);
		default:
			output = to_csv(wb);
	}*/
	output = to_formulae(wb);
	if(out.innerText === undefined) out.textContent = output;
	else out.innerText = output;
	if(typeof console !== 'undefined') console.log("output", new Date());
}
function setfmt() {if(global_wb) process_wb(global_wb); }

var drop = document.getElementById('drop');
function handleDrop(e) {
	e.stopPropagation();
	e.preventDefault();
	rABS = true;
	use_worker = true;
	var files = e.dataTransfer.files;
	var f = files[0];
	{
		var reader = new FileReader();
		var name = f.name;
		reader.onload = function(e) {
			if(typeof console !== 'undefined') console.log("onload", new Date(), rABS, use_worker);
			var data = e.target.result;
			if(use_worker) {
				xw(data, process_wb);
			} else {
				var wb;
				if(rABS) {
					wb = X.read(data, {type: 'binary'});
				} else {
					var arr = fixdata(data);
					wb = X.read(btoa(arr), {type: 'base64'});
				}
				process_wb(wb);
			}
		};
		if(rABS) reader.readAsBinaryString(f);
		else reader.readAsArrayBuffer(f);
	}
}

function handleDragover(e) {
	e.stopPropagation();
	e.preventDefault();
	e.dataTransfer.dropEffect = 'copy';
}

if(drop.addEventListener) {
	drop.addEventListener('dragenter', handleDragover, false);
	drop.addEventListener('dragover', handleDragover, false);
	drop.addEventListener('drop', handleDrop, false);
}


var xlf = document.getElementById('xlf');
function handleFile(e) {
	rABS = true;
	use_worker = true;
	var files = e.target.files;
	var f = files[0];
	{
		var reader = new FileReader();
		var name = f.name;
		reader.onload = function(e) {
			if(typeof console !== 'undefined') console.log("onload", new Date(), rABS, use_worker);
			var data = e.target.result;
			if(use_worker) {
				xw(data, process_wb);
			} else {
				var wb;
				if(rABS) {
					wb = X.read(data, {type: 'binary'});
				} else {
					var arr = fixdata(data);
					wb = X.read(btoa(arr), {type: 'base64'});
				}
				process_wb(wb);
			}
		};
		if(rABS) reader.readAsBinaryString(f);
		else reader.readAsArrayBuffer(f);
	}
}

if(xlf.addEventListener) xlf.addEventListener('change', handleFile, false);
var hdan = function () {
	chrome.tabs.create({ url: "http://ngxson.github.io/nhapdiem2017" });
}
var tacgia = function () {
	chrome.tabs.create({ url: "https://facebook.com/ngxson" });
}
document.getElementById("hdan").addEventListener("click", hdan);
document.getElementById("tacgia").addEventListener("click", tacgia);