load('signal.mat')
# N = 2048
# fe = 1000
# x: [1x2048]

t = (0:N-1)/fe;
f = (0:N-1)*fe/N;
spec_x = abs(fft(x));

# Chercher la liste des fréquences dans ce signal
[pics idx] = findpeaks(spec_x, 'MinPeakHeight', 200);
for i = idx
fprintf('%d Hz\n', f(i));
end

figure(1);

subplot(221);
plot(f, spec_x);
title('Spectre du signal enregistre');
