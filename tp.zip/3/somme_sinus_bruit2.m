N=2048;
fe=1200;
f1=48;
f2=52;
x = 0;
variance=200;
t=(0:N-1)/fe;
f=(0:N-1)*fe/N;
x1d=sin(2*pi*f1*t);
x2d=sin(2*pi*f2*t);
s=x1d+x2d;
for i = 1:100
x=x+s+sqrt(variance)*randn(size(s));
end
x=x/100;
figure(1);
subplot(121); plot(t,x); title("Ex3.3 N=2048");
subplot(122); plot(f,abs(fft(x))); title("Spectre d'amplitude, fe=1200");