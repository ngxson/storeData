N1=32;
N2=2048;
fe=256;
f1=100;
t1=(0:N1-1)/fe;
t=(0:N2-1)/fe;
f=(0:N2-1)*fe/N2;
x=sin(2*pi*f1*t1);
x_rect=x.*boxcar(32)';
x_rect=[x_rect zeros(1,N2-N1)];
sp_x_rect=abs(fft(x_rect));
 