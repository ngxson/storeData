load('ecg.mat');

spec_sg = abs(fft(ecg));
dt = 1/fe;
t = 0:dt:(length(ecg)*dt)-dt;
f = (0:length(spec_sg)-1)*fe/length(spec_sg);
[sg_x,lags] = xcorr(ecg);

figure(1);

subplot(221);
plot(t,ecg);
title('signal engeristre');
xlabel('t');
ylabel('');

subplot(222);
plot(f, spec_sg);
title('spectre d amplitude associe, fe=300Hz');
xlabel('');
ylabel('');

subplot(223);
plot(lags*dt,sg_x);
title('Auto coorelation, fe=22050');
xlabel('lags');
ylabel('');