load('sismo.mat');
x = zeros(3000,1);
dt = 1/fe;
t = 0:dt:(length(sg_cut2)*dt)-dt;
[sg_cutx,lags] = xcorr(sg_cut2);

figure(1);

subplot(211);
plot(t, sg_cut2);
title('1000 derniers points du signal Sismo');
xlabel('');
ylabel('');

subplot(212);
plot(lags*dt, sg_cutx);
title('Auto coorelation des 1000 derniers points');
xlabel('');
ylabel('');
