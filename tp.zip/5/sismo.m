load('sismo.mat');
sp_sg = abs(fft(sg));
dt = 1/fe;
t = 0:dt:(length(sg)*dt)-dt;
f=(0:length(sp_sg)-1)*fe/length(sp_sg);
[sg_x,lags] = xcorr(sg);

figure(1);

subplot(221);
plot(t,sg);title('signal engeristre');
xlabel('t');
ylabel('');

subplot(222);
plot(f, sp_sg);title('spectre d amplitude associe, fe=1kHz');
xlabel('');
ylabel('');

subplot(223);
plot(lags*dt,sg_x);
title('Auto correlation, fe=22050');
xlabel('lags');
ylabel('');